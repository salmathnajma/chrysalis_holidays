=== calypso ===

Contributors: creative asset
Tags: custom-logo, custom-menu, featured-images, threaded-comments, translation-ready,blog,grid-layout, one-column, two-columns, custom-background, custom-colors, custom-header,theme-options, threaded-comments,

Requires at least: 4.5
Tested up to: 5.0
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

Calypso fits all business, startups, corporate businesses, online companies, portfolios and freelancers.

== Description ==

Calypso is a modern WordPress theme for professionals. It fits creative business, small businesses, startups, corporate businesses, online agencies and firms, portfolios,  and freelancers. It has a multipurpose one-page design, widgetized footer, blog/news page and a clean look. The theme is responsive, WPML, Retina ready and SEO friendly.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Need to use any Subscription or Form plugin for subscription and contact functionalities.

== Changelog ==

= 1.0 - Jan 01 2019 =
* Initial release
