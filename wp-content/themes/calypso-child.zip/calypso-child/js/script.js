
jQuery(document).ready(function ($) {
  $('.single-post .comment-form textarea').attr('placeholder', 'Comments...');

  if (!navigator.userAgent.match(/(iPhone|Android)/)) {
    $('#call_button').click(function (e) {
      //alert ("Phone link is prevented from working since this is not a smartphone");
      var url = 'https://chrysalis.cahosting.biz/contact/';
      window.location.href = url;
      e.preventDefault();
    });
  }
 
//   if(post)
// {
//   $('').removeAttr('required')
// }

});
// jQuery(document).ready(function($) {
//   $('#email').attr('required', true);
// });