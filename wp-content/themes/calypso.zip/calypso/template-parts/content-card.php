<?php
/**
 * The card template for displaying post content on blog
 *
 * @package calypso
  */

do_action( 'ca_blog_post_template_part', 'card' );