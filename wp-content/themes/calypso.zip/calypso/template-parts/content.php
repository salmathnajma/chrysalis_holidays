<?php
/**
 * The default template for displaying post content
 *
 * @package calypso
 */

do_action( 'ca_blog_post_template_part', 'default' );

?>