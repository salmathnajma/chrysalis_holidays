<?php
/**
 * The alternative template for displaying post content on blog
 *
 * @package calypso
  */

do_action( 'ca_blog_post_template_part', 'alternative' );
