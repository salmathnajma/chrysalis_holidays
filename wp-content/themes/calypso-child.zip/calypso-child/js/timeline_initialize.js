jQuery(document).ready(function ($) {
    $.timeliner({});
    $('#timeline .timeline-wrapper').last().addClass('closed');
});